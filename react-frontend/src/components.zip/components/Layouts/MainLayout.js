import React from "react";

const MainLayout = (props) => {
    return <div className="layout-normal-container">{props.children}</div>;
};

export default MainLayout;
